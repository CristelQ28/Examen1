
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class UsuarioDAOArchivo {
    
    private String archivo = "usuarios.txt";
    
    // GUARDAR USUARIO
    
    public void guardarUsuario(Usuario usuario) throws IOException {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) {
            
            bw.write(usuario.toString());
            bw.newLine();
       
        }   
        
    }
    
    // LISTAR USUARIOS
    
    public List<Usuario> listarUsuarios() throws IOException {
        
        List<Usuario> lista = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            
            String linea;
            
            
            while ((linea = br.readLine()) ! = null) {
            
            String datos[] = linea.split(",");
            
            Usuario u = new Usuario(datos[0], datos[1]);
            
            lista.add(u);
            
            
        }
        }
        
        return lista;
        
    }
    

    
}

