
import java.io.IOException;


public class ServicioUsuario {
    
    private UsuarioDAOArchivo dao = UsuarioDAOArchivo();
    
    public void registrarUsuario(String nombre, String correo) throws IOException {
        
        //Validar
        
        if(nombre.isEmpty() || correo.isEmpty()) {
            
            System.out.println("Datos vacios");
            
            return;
            
        }
        
        Usuario u = new Usuario(datos[0], datos[1]); 
        
        dao.guardarUsuario(u);
        
    }
    
    public List<Usuario> obtenerUsuarios() trows IOException {
        
        return dao.listarUsuarios();
    }
    
}
