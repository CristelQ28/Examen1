
import java.io.IOException;
import java.util.Scanner;


public class App {
    
    public static void main(String [] args) {
        
        Scanner sc = new Scanner(System.in);
        
        ServicioUsuario servicio = new ServicioUsuario();
        
        try{
            
            System.out.println("Digite el nombre: ");
            String nombre = sc.nextLine();
            
            System.out.println("Digite el correo: ");
            String correo = sc.nextLine();
            
            servicio.registrarUsuario(nombre, correo);
            
            System.out.println("Usuarios Registrados: ");
            
            List<Usuario> lista = servicio.obtenerUsuarios();
            
            for(Usuario u : lista) {
                
                System.out.println(u.getNombre());
                System.out.println(u.getCorreo());
            }
 
        }
        
        catch (IOException e) {
            System.out.println("Error en el Sistema");
        }
        
        
    }
    
    
    
    
}
